#include <string>
#include <iostream>
#include <fstream>
#include "HashTable.h"
#include <windows.h>
#include <cstdlib>
#include <vector>
#include <algorithm>


using namespace std;

struct patient
{
    string m_idNum;
	string m_Name;
	string m_status;
	string m_date;
	patient *next;
};

class PMS
{

private:
	int Hash(const  string&);
	static const long long tableSize = 10000;
	patient* PatientTable[tableSize];

public:
	PMS();
	~PMS();
	void Insert( string ID,  string name ,string status, string date);
	void file(string I, string N, string S, string D);
	void Findpatient();
	void Search( string ID);
	string title;
	vector<string> PatientSort;

};

PMS::PMS()
{
	for (int i = 0; i < tableSize; i++)
	{
		PatientTable[i] = new patient;
		PatientTable[i]->m_Name =   " ";
		PatientTable[i]->m_idNum =  " ";
		PatientTable[i]->m_status = " ";
		PatientTable[i]->m_date =   " ";
		PatientTable[i]->next = NULL;
	}
}

PMS::~PMS()
{
	for (int i = 0; i < tableSize; i++)
	{
		delete PatientTable[i];
	}
}
int PMS::Hash(const  string& key)
{
	int hashValue = 0;
	for (int i = 0; i < key.length(); i++)
	{
		hashValue = int( 37 * hashValue + key[i]);

	}
	hashValue %= tableSize;

	if (hashValue < 0)
		hashValue += tableSize;

	return hashValue;
}

void PMS::Insert(string ID,string name, string status, string date)
{
	int index = Hash(ID);

	if (PatientTable[index]->m_idNum == "")
	{
		PatientTable[index]->m_idNum = ID;
		PatientTable[index]->m_Name = name;
		PatientTable[index]->m_status = status;
		PatientTable[index]->m_date = date;
	}
	else
	{
		patient* ptr = PatientTable[index];
		patient* newpatient = new patient;
		newpatient->m_Name = name;
		newpatient->m_idNum = ID;
		newpatient->m_status = status;
		newpatient->m_date = date;
		newpatient->next = NULL;
		while (ptr->next != NULL)
		{
			ptr = ptr->next;
		}
		ptr->next = newpatient;
	}

}
void PMS::file(string I, string N, string S, string D)
{
    fstream file;
    file.open("record.txt", ios::out | ios::in  | ios:: app);
    if (!file.is_open())
        cout << "Error in opening file\n";
    else
    {
        file << I<<"  " << N <<"\t  " << S <<"\t  " << D<<"\n";
        file.close();
    }

}
void PMS:: Findpatient()
{
    string digit;
    system("cls");
    cout<< " \n    CARONA MANAGEMENT SYSTEM\n";
    cout<< " ______________________________\n";
    cout<<"Search By:\n"
        <<"1.ID\n"
        <<"2.Date\n"
        <<"3.Test Status\n"<<endl;
    int enter;
    cin>>enter;
    switch(enter)
    {
    case 1:
        {
        cout << "\nEnter patients ID: ";
        cin >> digit;
        Search(digit);
        break;
        }
    case 2:
        {  //DATE
            ifstream file2;
            int variable,count=0;
            string search,line;
            cout<<"enter date to search: "<<endl;
            cin>>search ;
            file2.open("record.txt", ios::out | ios:: app | ios::in);
            if(file2.is_open())
            {
            while(!file2.eof())
            {
            while(getline(file2, line))
            {
            if ((variable = line.find(search)) != string::npos)
            {
               count++;cout << "found: " << search << endl;
            }
            else continue;
            }
            cout<<"Number of Entries on this date: "<<count<<endl;
            file2.close();
            }
            system("pause");
            break;
            }
            else cout<<"file not open"<<endl;

        }

    case 3:
        {  //TEST STATUS
            ifstream file3;
            int variable;string search2;
            string line;
            cout<<"enter status to search: "<<endl;
            cin>>search2 ;int count2=0;
            file3.open("record.txt", ios::out | ios:: app | ios::in);
            if(file3.is_open())
            {
            while(!file3.eof())
            {
            while(getline(file3, line))
            {
            if ((variable = line.find(search2)) != string::npos)
            {
              count2++;cout << "found: " << search2 << endl;
            }
            else continue;
            }
            cout<<"\nNumber of patients with "<<search2<<" results are:  "<<count2<<endl<<endl;
            }
            file3.close();
            system("pause");
            break;
            }
            else cout<<"file not open"<<endl;
    }
}
}

void PMS::Search(string ID)
{
	int index = Hash(ID);
	string name;
	string status;
	string date;
	bool found;
    int position;

	patient* ptr = PatientTable[index];
        while(ptr!=NULL)
        {
            if (ptr->m_idNum == ID )
            {
                position=index;found=true;
                name = ptr->m_Name;
                status = ptr->m_status;
                date = ptr->m_date;
            }
            ptr = ptr->next;

        }

        if (found==true)
        {
             cout << "------------------------------------------\n";
             cout << " Name of patient: " << name
                  <<" \n At Position: "<< position
                  <<" \n status: " << status
                  << "\n Date: "<< date << endl<<endl;
             cout << "------------------------------------------\n";
             system("pause");
        }


        else
        { found=false;
          cout << "---------------------------------\n";
		  cout << " No patient exist with that ID" <<  endl;
		  cout << "----------------------------------\n";
		  system("pause");
        }

}

void print(vector<string> const &input)
{
    for (int i = 0; i < input.size(); i++) {
        cout << input.at(i) << endl;
    }

}

int main()
{
	PMS C;
	ifstream file1("record.txt");
	int option;
	string PID;
	string PName,PStatus,PDate;

	if (!file1.is_open())
	{
		cout << "Error in opening file\n";
	}
	else
	{
		while (file1 >> PID >> PName>>PStatus>>PDate)
		{
			C.Insert(PID, PName,PStatus,PDate);
		}

		file1.close();
	}


    int choice;
	do
	{
        system("cls");
        cout << " \n    CARONA MANAGEMENT SYSTEM\n";
        cout << " ______________________________\n";
        cout << " 1.)Insert\n";
        cout << " 2.)search\n";
        cout << " 3.)Sorted Display\n";
        cout << " 4.)Exit\n";
        cout << " Enter option:";
        cin  >> choice;
		switch (choice)
		{
			case 1:
            {
                string id1, name1,status1,date1;
                cout<<"enter id: "<<endl;
                cin>>id1;
                cout<<"enter name: "<<endl;
                cin>>name1;
                cout<<"enter status: "<<endl;
                cin>>status1;
                cout<<"enter date: "<<endl;
                cin>>date1;
                C.Insert(id1,name1,status1,date1);
                C.file(id1,name1,status1,date1);
                break;
			}
			case 2:C.Findpatient();break;
            case 3:
            {
    ifstream file4("record.txt");
    if (!file4)
    {
        cout << "Could not open file\n";
        return 1;
    }
    while (true)
    {
        PMS C;
        if (!getline(file4, C.title))
        {
            cout << "\n<end of file reached, no more patients>\n\n";
            system("pause");
            break;
        }
        while (true)
        {
            string P;
            if (getline(file4, P))
            {
                if (file4.eof())
                {
                    sort(C.PatientSort.begin(), C.PatientSort.end());
                    break;
                }
                else
                {
                    C.PatientSort.push_back(P);
                }
            }
            else
            {
                sort(C.PatientSort.begin(), C.PatientSort.end());
                break;
            }
        }
        cout<<"\nID\t\tNAME\t STATUS\t\t  DATE"<<endl;
        print(C.PatientSort);
    }

              }
}
    }while (choice != 4);
	return 0;
}
